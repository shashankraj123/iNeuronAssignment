package first.Assignment;

public class BreakExecution {

	public static void main(String[] args) {
		int[] numbers = {12,34,66,85,900};
		for(int i=0; i<numbers.length; i++)
		{
			if(numbers[i]==85)
			{
				System.out.println("Found "+numbers[i]);
				break;
		}

	}

}
}
