package first.Assignment;

public class PrimeNumbers {

	public static void main(String[] args) {
		int i =0;
	       int number =0;
	       

	       for (i = 1; i <= 1000; i++)         
	       { 		  	  
	          int count=0; 	  
	          for(number =i; number>=1; number--)
		  {
	             if(i%number==0)
		     {
	 		count = count + 1;
		     }
		  }
		  if (count ==2)
		  {
			  System.out.println(i);
		  }	
	       }	
	       

	}

}
