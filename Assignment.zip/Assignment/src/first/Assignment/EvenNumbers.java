package first.Assignment;

public class EvenNumbers {

	public static void main(String[] args) {
		for(int i=0; i<=200; i+=2)
		{
			if(i==0)
			{
				continue;
			}
			System.out.println(i);
		}

	}

}
