package first.Assignment;

public class SumOfNumbers {

	public static void main(String[] args) {
		int a =10;
		double b=90.78;
		int c=111;
		int d =8989;
		int e=7876;
		double sum=0;
		System.out.println("Sum of numbers: "+(a+b+c+d+e));

	}

}
