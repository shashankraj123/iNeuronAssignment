package first.Assignment;

public class BreakStringExecution {

	public static void main(String[] args) {
		String[] words = {"Java","JavaScript","Selenium","Python","Mukesh"};
		for(String word: words) {
			if(word.equalsIgnoreCase("Selenium"))
			{
				System.out.println("Found word: "+word);
				break;
			}
		}
		

	}

}
