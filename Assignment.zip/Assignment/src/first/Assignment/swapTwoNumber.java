package first.Assignment;

public class swapTwoNumber {

	public static void main(String[] args) {
		int a =10;
		int b=20;
		System.out.println("First Number :"+a);
		System.out.println("Second Number :"+b);
		System.out.println("Swapping the numbers");
		int temp=0;
		temp=a;
		a=b;
		b=temp;
		System.out.println("Swapped Numbers :" +" a:"+a + " b:"+b);
		

	}

}
